/**
  * @author Rodrigo Jeria
  * @version 1.0
*/

'use strict'

var express = require('express');
var bodyParser = require('body-parser');
var app = express();

// Variable para aplicar colores a la consola
var style = require('./style');

// Libreria Moment para mostrar hora
var moment = require('moment');
	moment.locale('es');

	// Calcular la hora y aplicar formato
	function showClock(){
		return String("["+moment().format('DD/MM/YY H:mm:ss')+"] ");
	}


// Cargar Rutas
var user_routes = require('./routes/user');

// Middlewares
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

// Configurar Cabeceras y CORS
app.use((req,res,next)=>{
	res.header('Access-Control-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
	res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
	res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
	next();
});

// Rutas base
app.use('/api', user_routes);


// Exportar módulo
module.exports = app;