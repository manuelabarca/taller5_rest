/**
  * @author Rodrigo Jeria
  * @version 1.0
*/

'use strict'

//Modulos necesarios
var moment = require('moment');
	moment.locale('es');
var nodemailer = require('nodemailer');

// Modelos de datos
var User = require('../models/user');
	
	// Calcular la hora y aplicar formato
	function showClock(){
		return String("["+moment().format('DD/MM/YY H:mm:ss')+"] ");
	}

function sendMail(req,res){

	if(!req.body.message || req.body.message == ""){
		return res.status(200).send({
			message : "Error: Se necesita un mensaje con contenido"
		});
	}

	if(!req.body.user || req.body.user == ""){
		return res.status(200).send({
			message : "Error: Se necesita la información del usuario"
		});
	}

	var smtpConfig = {
		host: 'mail.sentra.cl',
		port: 25,
		auth: {
			user: 'rjeria@sentra.cl',
			pass: '017p3rr0'
		}
	};

	// Definimos el transporter
	var transporter = nodemailer.createTransport(smtpConfig);

	// Definimos el email
	var mailOptions = {
		from: 'rjeria@sentra.cl',
		to: req.body.user.mail,
		subject: 'Te ha enviado un mensaje',
		html: req.body.message
	};

	// Enviamos el email
	transporter.sendMail(mailOptions, function (error, info) {
		if (error) {
			console.log(error);
			return res.status(200).send({
				message : "Ha ocurrido un error al enviar el correo",
				error : err,
				success : false
			});
		} else {
			return res.status(200).send({
				message : 'Mensaje enviado correctamente',
				success : true
			});
		}
	});

}	


function getUserById(req,res){

	if(!req.params.id){
		return res.status(200).send({
			message : "Error: Se necesita incluir la id del usuario"
		});
	}

	User.findOne({"id" : req.params.id}).exec((err, result)=>{

		if(err){
			console.log(err)
			return res.status(200).send({
				message : "Error en el Servidor",
				error : err
			});
		}

		if(result){
			
			return res.status(200).send({
				user : result
			});

		}else{

			return res.status(200).send({
				message : "No se encontró el usuario"
			});

		}

	});

}

function getUsers(req,res){
	
	User.find().exec((err, result)=>{

		if(err){	
			console.log(err)
			return res.status(200).send({
				message : "Error en el Servidor",
				error : err
			});
		}

		if(result && result.length > 0){
			
			return res.status(200).send({
				users : result
			});

		}else{

			return res.status(200).send({
				message : "No se encuentran usuarios"
			});

		}

	});

}

module.exports = {
	getUsers,
	getUserById,
	sendMail
}