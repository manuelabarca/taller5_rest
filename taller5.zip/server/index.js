/**
  * @author Rodrigo Jeria
  * @version 1.0
*/

'use strict'

// Variables necesarias para levantar el Servidor
var mongoose = require('mongoose');
var app = require('./app');
var port = 4000;

// Decoración de la consola
var style = require('./style');
var moment = require('moment');
moment.locale('es');

// Devuelve la hora actual, ideal para mostrar en consola.
function showClock(){
	return String("["+moment().format('DD/MM/YY H:mm:ss')+"] "); // Formato --> [21-03-2017 11:22:54]
}


// Levanta el Servidor Node
mongoose.Promise  = global.Promise;
mongoose.connect('mongodb://localhost:27017/taller5', { useMongoClient: true})
	.then(() => {
		console.log(showClock()+ style.green, "Conexión con MongoDB establecida");
		app.listen(port, () => {
			console.log(showClock()+ style.green, "Servidor Node está corriendo en el puerto: " + port)
		})
	})
  .catch(err => console.log(err));
  