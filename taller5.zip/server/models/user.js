/**
  * @author Rodrigo Jeria
  * @version 1.0
*/

'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var UserSchema = Schema({
	name: String,
	id: Number,
	lastname: String,
	mail : String,
	age : Number,
	country : String,
	avatar : String
});

module.exports = mongoose.model('User', UserSchema);