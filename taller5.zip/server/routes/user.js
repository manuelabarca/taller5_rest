/**
  * @author Rodrigo Jeria
  * @version 1.0
*/

'use strict'

var express = require('express');
var UserController = require('../controllers/user');

var api = express.Router();

api.get('/users', UserController.getUsers);
api.get('/user/:id', UserController.getUserById);
api.post('/mail', UserController.sendMail);

module.exports = api;