/**
  * @author Rodrigo Jeria
  * @version 1.0
*/

/*Define colores para la consola

	Ej: Mostrar un mensaje en color verde
		console.log(style.green, "hola mundo")
		
*/

var style = {
	none : '\x1b[0m\x1b[0m',
	red : '\x1b[31m%s\x1b[0m',
	green : '\x1b[32m%s\x1b[0m',
	yellow : '\x1b[33m%s\x1b[0m',
	blue : '\x1b[34m%s\x1b[0m'
}

module.exports = style;